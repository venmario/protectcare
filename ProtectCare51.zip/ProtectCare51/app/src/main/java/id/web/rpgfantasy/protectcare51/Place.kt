package id.web.rpgfantasy.protectcare51

data class Place(val id:String, val name:String){
    override fun toString(): String {
        return name
    }
}
