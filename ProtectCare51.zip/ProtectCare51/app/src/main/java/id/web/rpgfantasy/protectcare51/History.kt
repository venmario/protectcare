package id.web.rpgfantasy.protectcare51

data class History(val id:Int, val location:String, val checkin:String, val checkout:String, val vaccine:Int){

}
