package id.web.rpgfantasy.protectcare51

object GlobalData {
    val history: ArrayList<History> = arrayListOf(

    )
    var places:ArrayList<Place> = arrayListOf()
}